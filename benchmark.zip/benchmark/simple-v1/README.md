# 瓷器三维重建小测试集 v1


## 先看目录：只按这一个规则存放

```text
benchmark/simple-v1/
├─ inputs/                         # 唯一的测试输入：6 张固定图片
├─ member-a/                       # A （张展华）的模型文件、日志、小报告
│  ├─ triposr/P01/output.glb
│  └─ sf3d/P01/output.glb
├─ member-b/                       # B （赵佳政）的模型文件、日志、小报告
│  ├─ instantmesh/P01/output.glb
│  └─ meshroom/MV01/output.glb
├─ screenshots/                    # 所有截图统一放这里
│  └─ triposr/P01/front.png
├─ manifest.csv                    # 6 张输入图与测试重点
├─ comparison.md                   # 小组共同填写的总对比表
└─ score-template.csv              # 可用 Excel 打开的原始评分表
```

**不要再从 `backend/data/images` 或根目录选图。** 本测试中唯一允许作为输入的文件就是 `inputs/` 下面的 6 张图片。

## 六张固定输入图

| 编号 | 必须使用的文件 | 主要难点 |
|---|---|---|
| P01 | `inputs/P01-black-glazed-jar.jpg` | 深色、高光、圆罐、圈足 |
| P02 | `inputs/P02-relief-meiping.jpg` | 浅色浮雕、长颈、对称轮廓 |
| P03 | `inputs/P03-green-spouted-vessel.jpg` | 非对称出流/把手、贴塑 |
| P04 | `inputs/P04-blue-white-double-ear-jar.jpg` | 青花复杂纹饰、双耳 |
| P05 | `inputs/P05-green-openwork-ear-vase.jpg` | 镂空双耳、细长器颈 |
| P06 | `inputs/P06-blue-white-moon-flask.jpg` | 扁平器身、双耳、正面纹饰 |

P01～P05 是项目中已有的克利夫兰艺术博物馆 CC0 图片。P06 是组内测试图，只用于内部比较；公开展示前确认其来源和使用权。

## 两位队员的分工

| 人员 | 方法 | 输出目录 |
|---|---|---|
| 队员 A | TripoSR、SF3D | `member-a/triposr/`、`member-a/sf3d/` |
| 队员 B | InstantMesh、Meshroom | `member-b/instantmesh/`、`member-b/meshroom/` |

本轮不把 Hunyuan3D 作为必做方法：本机显卡为 RTX 4060 Laptop（8GB 显存），而 Hunyuan3D 2.1 官方标注形状生成约需 10GB 显存、纹理生成约需 21GB 显存。本轮先选择更容易本地复现的 InstantMesh；以后有云端或高显存机器时，再单独加做 Hunyuan3D 对照。

Meshroom 是多图方法，不跑 P01～P06。队员 B 自己选 1 个可拍摄的陶瓷物体，拍 12～20 张环绕照片，编号为 `MV01`，只与该物体的一张正面照片的单图结果比较。

## 每次运行只交 5 样东西

以 TripoSR 的 P01 为例：

```text
member-a/triposr/P01/
  output.glb            # 模型；若没有 GLB，保留 OBJ/PLY
  run.md                # 运行记录

screenshots/triposr/P01/
  front.png
  side.png
  back.png
```

`run.md` 固定写 6 项：方法和版本、运行人、日期、设备/显卡、生成时间（不含下载权重）、成功/失败和问题。

同一张图片最多重试两次。两次失败也要创建 `run.md`，写明失败原因；不要悄悄跳过难图。

## 评分：只看四项

每项 0～5 分，视觉总分满分 20。生成时间只记录秒数，不和质量分相加。

| 项目 | 看什么 |
|---|---|
| 器型轮廓 | 高矮、胖瘦、口沿、底足像不像 |
| 关键结构 | 耳、把、出流、镂空是否存在且自然 |
| 颜色纹饰 | 正面颜色和主要纹样是否接近 |
| 网页可用性 | 是否能导入网页、正常旋转、没有明显破面 |

评分标准：0=失败；1=严重不对；2=可识别但问题明显；3=基本可用；4=效果好；5=适合展示。

运行人可以先填分，但最终分由**另一位未负责该方法的成员**看截图复核后填写。总表只认复核分。

## 最后共同完成什么

1. 一起填完 `comparison.md`；
2. 每种方法至少展示一组“输入图 + 正面 + 侧面 + 背面”；
3. 写 3 句话结论：快速单图推荐什么、高质量单图推荐什么、多图模式值不值得做；
4. 明确写出：单图的背面、底部和厚度是模型推断，不是真实扫描。
