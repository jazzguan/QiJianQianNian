# 队员 A 的提交位置

- TripoSR：`triposr/P01/` 到 `triposr/P06/`
- SF3D：`sf3d/P01/` 到 `sf3d/P06/`

每个样本目录只放 `output.glb`（或原始模型文件）和 `run.md`。截图统一放到 `../../screenshots/方法名/样本编号/`。
