# 队员 B 的提交位置

- InstantMesh：`instantmesh/P01/` 到 `instantmesh/P06/`
- Meshroom：`meshroom/MV01/`

截图统一放到 `../../screenshots/方法名/样本编号/`。本轮不要求安装 Hunyuan3D：本机 8GB 显存不足以稳定运行它的官方完整流程。
